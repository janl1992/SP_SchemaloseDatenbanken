create function recursivesearch(tinput integer[], irecursiondepth integer, stable text) returns SETOF integer
  language plpgsql
as
$$
Declare
  intermDst_ integer[];
  iCount integer;
BEGIN
  CREATE TEMPORARY TABLE intermDst AS SELECT * FROM unnest(tInput);
  EXECUTE 'CREATE TEMPORARY TABLE intermDst1 AS SELECT DISTINCT(dst) FROM ' || sTable || ' WHERE src IN (SELECT * FROM intermDst)';
  -- Does not return from function!
  return query SELECT * FROM intermDst1;
  -- Does not return from function!
  intermDst_ := ARRAY(SELECT * FROM intermDst1);
  raise notice 'timestamp: %', clock_timestamp();
  SELECT count(*) INTO iCount FROM intermDst;
  raise notice 'Count Table: %', iCount;
  DROP TABLE intermDst;
  DROP TABLE intermDst1;
  if iRecursionDepth > 1 THEN
    return query SELECT * FROM recursivesearch(intermDst_, iRecursionDepth - 1, sTable);
  ELSE
    RETURN;
  END IF;
END;
$$;

alter function recursivesearch(integer[], integer, text) owner to postgres;

