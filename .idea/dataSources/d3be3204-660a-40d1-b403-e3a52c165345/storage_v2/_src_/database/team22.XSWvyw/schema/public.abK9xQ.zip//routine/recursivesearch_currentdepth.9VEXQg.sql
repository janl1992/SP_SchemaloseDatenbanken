create function recursivesearch_currentdepth(tinput integer[], irecursiondepth integer, stable text) returns SETOF integer
  language plpgsql
as
$$
Declare
  intermDst_ integer[];
  iCount integer;
  intermDst VARCHAR := 'intermDst'||iRecursionDepth;
  intermDst1 VARCHAR := 'intermDst1'||iRecursionDepth;
BEGIN
  EXECUTE 'CREATE TEMPORARY TABLE '||intermDst||' as with t (src) as ( VALUES ('||array_to_string(tInput, ',', '*')||'))select * from t';
  EXECUTE 'CREATE TEMPORARY TABLE '||intermDst1||' AS SELECT DISTINCT(dst) FROM ' || sTable || ' WHERE src IN (SELECT * FROM '|| intermDst||')';
  -- Does not return from function!

  -- Does not return from function!
  execute 'Create temporary Table tmp1 as (SELECT * FROM '|| intermDst1|| ')';
  intermDst_ :=  ARRAY(SELECT  * from tmp1);
  return query SELECT * FROM tmp1;
  Drop Table tmp1;
  execute 'DROP TABLE '|| intermDst;
  execute 'DROP TABLE '|| intermDst1;
  if iRecursionDepth > 1 THEN
    return query SELECT * FROM recursivesearch(intermDst_, iRecursionDepth - 1, sTable);
  ELSE
  return;
  END IF;
END;
$$;

alter function recursivesearch_currentdepth(integer[], integer, text) owner to postgres;

