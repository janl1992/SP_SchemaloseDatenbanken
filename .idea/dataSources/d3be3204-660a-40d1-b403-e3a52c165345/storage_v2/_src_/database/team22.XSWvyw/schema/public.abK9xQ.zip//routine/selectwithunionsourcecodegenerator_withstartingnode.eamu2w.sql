create function selectwithunionsourcecodegenerator_withstartingnode(stable text, startingnode integer, depth integer) returns SETOF integer
  language plpgsql
as
$$
Declare
  intermDst_ integer[];
  tStatement text;
  tSelectStatement text;
  tWithStatement text;
  tUnionStatement text;
  tWithStatementClose text;
BEGIN
  tWithStatement := 'WITH RECURSIVE graphtraverse(src, dst, lvl) AS(';
  tSelectStatement := 'SELECT src ,dst, 1 as lvl FROM ' || sTable || ' WHERE src ='||startingNode;
  tUnionStatement := ' UNION SELECT p1.src,p1.dst,p.lvl+1 as lvl FROM graphtraverse p, ' || sTable || ' p1 WHERE p1.src IN ( p.dst ) and lvl<'||depth;
  tWithStatementClose := ') SELECT (dst) FROM graphtraverse';
  tStatement := tWithStatement || tSelectStatement || tUnionStatement || tWithStatementClose;
  raise notice 'Execute String %', tStatement;
  return query EXECUTE tStatement;
END;
$$;

alter function selectwithunionsourcecodegenerator_withstartingnode(text, integer, integer) owner to postgres;

